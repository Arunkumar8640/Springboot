package com.cts.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.product.TaskDAO.TaskDAO;
import com.cts.product.pojo.Task;
@Service
public class Taskservice {
	@Autowired
	TaskDAO taskdao;
	public List<Task> getalltodo() {
		// TODO Auto-generated method stub
		return taskdao.getalltodo();
	}
	public void savetodo(Task t) {
		// TODO Auto-generated method stub
		taskdao.savetodo(t);
	}
	public List<Task> updatestatus(int id) {
		// TODO Auto-generated method stub
		return taskdao.updatestatus(id);
	}

}
