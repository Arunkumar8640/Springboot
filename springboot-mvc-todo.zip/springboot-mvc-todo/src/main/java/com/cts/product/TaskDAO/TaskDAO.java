package com.cts.product.TaskDAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.product.entity.Taskentity;
import com.cts.product.pojo.Task;
import com.cts.product.repository.Taskrepository;
@Repository
public class TaskDAO {
	@Autowired
	Taskrepository taskrepository;
	public List<Task> getalltodo() {
		// TODO Auto-generated method stub
		List<Taskentity> te=taskrepository.findAll();
		List<Task> t = new ArrayList<Task>();
		for(Taskentity tetemp: te )
		{
			Task ttemp = new Task();
			ttemp.setId(tetemp.getId());
			ttemp.setTask(tetemp.getTask());
			ttemp.setStatus(tetemp.getStatus());
			ttemp.setSuspendstatus(tetemp.getSuspendstatus());
			t.add(ttemp);
		}
		return t;
	}
	public void savetodo(Task t) {
		// TODO Auto-generated method stub
		Taskentity te= new Taskentity();
		te.setTask(t.getTask());
		te.setStatus(t.getStatus());
		te.setSuspendstatus(t.getSuspendstatus());
		taskrepository.save(te);
	}
	public List<Task> updatestatus(int id) {
		// TODO Auto-generated method stub
		Taskentity tent = taskrepository.findById(id).get();
		tent.setStatus("done");
		taskrepository.saveAndFlush(tent);
		List<Taskentity> te=taskrepository.findAll();
		List<Task> t = new ArrayList<Task>();
		for(Taskentity tetemp: te )
		{
			Task ttemp = new Task();
			ttemp.setId(tetemp.getId());
			ttemp.setTask(tetemp.getTask());
			ttemp.setStatus(tetemp.getStatus());
			ttemp.setSuspendstatus(tetemp.getSuspendstatus());
			t.add(ttemp);
		}
		return t;
	}

}
