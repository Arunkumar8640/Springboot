package com.cts.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.product.pojo.Task;
import com.cts.product.service.Taskservice;

@RestController
public class Webcontroller {
	@Autowired
	Taskservice service1;
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public void savetodo(@RequestBody Task task)
	{
		service1.savetodo(task);
	}
	@GetMapping("/all")
	public List<Task> getalltodo()
	{
		return service1.getalltodo();
	}
	@PostMapping("/status/{myid}")
	public List<Task> updatestatus(@PathVariable("myid") int id)
	{
		return service1.updatestatus(id);
	}
}
