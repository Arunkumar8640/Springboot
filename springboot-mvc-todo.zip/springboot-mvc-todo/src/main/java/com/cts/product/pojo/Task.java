package com.cts.product.pojo;

public class Task {
	int id;
	private String task;
	private String status;
	private String suspendstatus;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSuspendstatus() {
		return suspendstatus;
	}
	public void setSuspendstatus(String suspendstatus) {
		this.suspendstatus = suspendstatus;
	}
	
	
}
