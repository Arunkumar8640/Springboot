package com.cts.STShelloworld.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.STShelloworld.demo.Friend;
import com.cts.STShelloworld.demo.service.FriendService;

@RestController
@RequestMapping("/api")
public class Hellocontroller {
	@Autowired
	private FriendService friendservice;
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String welcomeGet()
	{
		return("Helloworld to get");
	}
	@RequestMapping(value="/welcome",method=RequestMethod.POST)
	public String welcomePost()
	{
		return("Helloworld to post");
	}
	@RequestMapping(value="/welcome",method=RequestMethod.PUT)
	public String welcomePut()
	{
		return("Helloworld to put");
	}
	@RequestMapping(value="/welcome",method=RequestMethod.DELETE)
	public String welcomeDelete()
	{
		return("Helloworld to delete");
	}
	@GetMapping("/all")
	public List<Friend> listFriends()
	{
	return friendservice.getallfriends();
	}
	@RequestMapping(value="/get/{id}")
	public Friend getfriendbyid(@PathVariable String id)
	{
		return friendservice.getfriendbyid(id);
	}
	@GetMapping("/get/{myid}")
	
}
