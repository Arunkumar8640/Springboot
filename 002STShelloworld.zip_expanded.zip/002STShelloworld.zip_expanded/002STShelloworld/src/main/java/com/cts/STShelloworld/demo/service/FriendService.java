package com.cts.STShelloworld.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.STShelloworld.demo.Friend;
import com.cts.STShelloworld.demo.FriendDAO;

@Service("friendservice")
public class FriendService {
	@Autowired
	private FriendDAO friendDao;
	
	public List<Friend> getallfriends()
	{
		return friendDao.getAllFriends();
	}

	public Friend getfriendbyid(String id) {
		// TODO Auto-generated method stub
		return friendDao.getfriendbyid(id);
	}
}
