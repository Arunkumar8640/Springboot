package com.cts.STShelloworld.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class FriendDAO {
	
	private List<Friend> friends = new ArrayList<>(Arrays.asList(new Friend("Ola",21,"1")
			,new Friend("Uber",22,"2"),
			 new Friend("Zoom",23,"3")));

	public List<Friend> getAllFriends()
	{
	/*	List<Friend>  friends = new ArrayList<>();
		Friend f1 = new Friend();
		f1.setAge(20);
		f1.setName("Ola");
		friends.add(f1);
		
		Friend f2 = new Friend();
		f2.setAge(25);
		f2.setName("Uber");
		friends.add(f2);*/
		return friends;
	}

	public Friend getfriendbyid(String id) {
		// TODO Auto-generated method stub
		return friends.stream().filter((f) -> f.getId().equals(id)).findFirst().get();
		
	}
}
